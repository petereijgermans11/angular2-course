# VoorbeeldenAngular2
Voorbeelden en demo's bij de training Angular 2 (Peter Kassenaar <info@kassenaar.com>)

# Gebruik
Clone de repo en draai in de submappen van \oefeningen de opdracht `npm install` om de dependencies 
per project te installeren. 

Zie de oefeningen en slides voor verdere informatie. 
