// city.add.component.ts
import { Component } from '@angular/core';

@Component({
	selector: 'add-city',
	template: `<h1>Add City</h1>
	<h2>Todo...</h2>	
	`
})

export class CityAddComponent{

}
