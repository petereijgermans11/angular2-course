Vanaf dit punt: je *kunt* een nieuw project initialiseren met npm install.

Dan heb je een startpunt dat gelijk is aan het einde van de vorige stappen. Nieuw is dat hier Bootstrap is toegevoegd als dependency voor wat mooiere layout.

Je mag ook verder gaan op basis van je vorige project.