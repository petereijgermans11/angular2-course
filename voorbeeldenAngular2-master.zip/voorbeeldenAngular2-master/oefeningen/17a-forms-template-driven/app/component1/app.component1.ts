import {Component, OnInit} from '@angular/core';

@Component({
	selector   : 'component1',
	templateUrl: 'app/component1/app.component1.html'
})
export class AppComponent1 implements OnInit {

	constructor() {
	}

	ngOnInit() {
	}
}

