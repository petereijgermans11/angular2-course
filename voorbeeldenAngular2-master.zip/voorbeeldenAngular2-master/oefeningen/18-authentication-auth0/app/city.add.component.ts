// city.add.component.ts
import { Component } from '@angular/core';

@Component({
	selector: 'add-city',
	template: `<h1>Add City</h1>
	<h2>Can only add city when authenticated</h2>
	<p>Todo....</p>
	`
})

export class CityAddComponent{

}
